import React, { useState,useEffect } from 'react'
import logo from './logo.svg'
import './App.css'
import { Button } from 'antd';
import { Login } from './services/login'

function App() {
  const [count, setCount] = useState(0)
  useEffect(() => {
    console.log('生命周期')
  }, []);
  const login = () => {
    Login().then(e=>{
      console.log(e)
    })
  }
  return (
    <div className="App">
      <Button type="primary" onClick={ () => login() }>login</Button>
      <Button onClick={()=>setCount(count+1)}>{count}</Button>
    </div>
  )
}

export default App
